const express = require("express");
const jwt = require("jsonwebtoken");

const authMiddleware = require("./middleware/auth");

const app = express();

const PORT = 3000;

const SECRET_KEY = "student_secret_key";

app.use(express.json());


// Temporary database

let users = [];

let students = [
    {
        id: 1,
        name: "Rahul",
        department: "CSE"
    },
    {
        id: 2,
        name: "Priya",
        department: "AI"
    }
];


// Home API

app.get("/", (req, res) => {

    res.json({
        message: "Welcome to Secure Student API"
    });

});


// Register API

app.post("/register", (req, res) => {

    const { username, password, role } = req.body;

    const existingUser =
        users.find(user => user.username === username);

    if (existingUser) {

        return res.status(400).json({
            message: "User already exists"
        });

    }

    const newUser = {

        id: users.length + 1,

        username,

        password,

        role: role || "student"

    };

    users.push(newUser);

    res.json({

        message: "User registered successfully"

    });

});


// Login API

app.post("/login", (req, res) => {

    const { username, password } = req.body;

    const user =
        users.find(
            u =>
                u.username === username &&
                u.password === password
        );

    if (!user) {

        return res.status(401).json({

            message: "Invalid username or password"

        });

    }

    const token = jwt.sign(

        {
            userId: user.id,
            role: user.role
        },

        SECRET_KEY,

        {
            expiresIn: "1h"
        }

    );

    res.json({

        message: "Login successful",

        token: token

    });

});


// Protected Student APIs

app.get(
    "/students",
    authMiddleware,
    (req, res) => {

        res.json(students);

    }
);


// Add student

app.post(
    "/students",
    authMiddleware,
    (req, res) => {

        const student = {

            id: students.length + 1,

            name: req.body.name,

            department: req.body.department

        };

        students.push(student);

        res.json({

            message: "Student added",

            student

        });

    }
);


// Get student by ID

app.get(
    "/students/:id",
    authMiddleware,
    (req, res) => {

        const student =
            students.find(
                s => s.id == req.params.id
            );

        if (!student) {

            return res.status(404).json({

                message: "Student not found"

            });

        }

        res.json(student);

    }
);


// 404 middleware

app.use((req, res) => {

    res.status(404).json({

        message: "Route not found"

    });

});


// Start server

app.listen(PORT, () => {

    console.log(
        `Server running at http://localhost:${PORT}`
    );

});